package am.aua.quarto.core.figures;
/**
 * The HeightJoker class encapsulates the behavior of the figures
 * called height jokers that can match with any figure by height.
 * It is a subclass of ExtraFigure base class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class HeightJoker extends ExtraFigure {

    /**
     * Constructs a new HeightJoker object given the color,
     * shape and form of it.
     *
     * @param color        The Color color of the figure
     * @param shape         The Shape shape of the figure
     * @param form          The Form form of the figure
     */
    public HeightJoker(Color color, Shape shape, Form form){
        this.height = null;
        this.shape = shape;
        this.form = form;
        this.color = color;
    }


    /**
     * Returns true if compared with another figure
     * regarding the height characteristic.
     *
     * @param other     Figure object
     * @return          true, as it matches with any object by height
     */
    public boolean isSameHeight(Figure other){
        return  true;
    }
}
