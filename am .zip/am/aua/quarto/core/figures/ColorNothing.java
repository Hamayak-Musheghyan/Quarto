package am.aua.quarto.core.figures;

/**
 * The ColorNothing class encapsulates the behavior of the figures
 * called color nothings that don't match with any figure by color.
 * It is a subclass of ExtraFigure base class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class ColorNothing extends ExtraFigure {
    /**
     * Constructs a new ColorNothing object given the height,
     * shape and form of it.
     *
     * @param height        The Height height of the figure
     * @param shape         The Shape shape of the figure
     * @param form          The Form form of the figure
     */
    public ColorNothing(Height height, Shape shape, Form form){
        this.height = height;
        this.shape = shape;
        this.form = form;
        this.color = null;
    }


    /**
     * Returns false if compared with another figure
     * regarding the color characteristic.
     *
     * @param other     Figure object
     * @return          false, as it doesn't match with any object by color
     */
    public boolean isSameColor(Figure other){
        return  false;
    }
}
