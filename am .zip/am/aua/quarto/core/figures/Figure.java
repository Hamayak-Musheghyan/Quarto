package am.aua.quarto.core.figures;

/**
 * The Figure class encapsulates the behavior of the figures for the Quarto game.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class Figure implements Puttable, Cloneable{

    /**
     * The color of the figure.
     */
    Color color;
    /**
     * The height of the figure.
     */
    Height height;
    /**
     * The shape of the figure.
     */
    Shape shape;
    /**
     * The form of the figure.
     */
    Form form;



    public enum Color{WHITE, BLACK};
    public enum Height{TALL, SHORT};
    public enum Shape{ROUND, SQUARE};
    public enum Form{SOLID, HOLLOW};

    /**
     * Constructs a new white, tall, round and solid Figure object.
     */
    public Figure(){
        this(Color.WHITE, Height.TALL, Shape.ROUND, Form.SOLID);
    }

    /**
     * Constructs a new figure with the given features as parameters.
     *
     * @param color     The color of the Figure object
     * @param height    The height of the Figure object
     * @param shape     The shape of the Figure object
     * @param form      The form of the Figure object
     */
    public Figure(Color color, Height height, Shape shape, Form form){
        this.color = color;
        this.height = height;
        this.shape = shape;
        this.form = form;
    }

    /**
     * Returns the color of the figure.
     *
     * @return      The Color color of the figure
     */
    public Color getColor(){
        return this.color;
    }

    /**
     * Returns the height of the figure.
     *
     * @return      The Height height of the figure
     */
    public Height getHeight(){
        return this.height;
    }

    /**
     * Returns the shape of the figure.
     *
     * @return      The Shape shape of the figure
     */
    public Shape getShape(){
        return this.shape;
    }

    /**
     * Returns the form of the figure.
     *
     * @return      The Form form of the figure
     */
    public Form getForm(){
        return this.form;
    }

    /**
     * Sets the color to the corresponding parameter.
     *
     * @param color     The new color for the figure
     */
    public void setColor(Color color){
        this.color = color;
    }

    /**
     * Sets the height to the corresponding parameter.
     *
     * @param height     The new height for the figure
     */
    public void setHeight(Height height){
        this.height = height;
    }

    /**
     * Sets the shape to the corresponding parameter.
     *
     * @param shape     The new shape for the figure
     */
    public void setShape(Shape shape){
        this.shape = shape;
    }

    /**
     * Sets the form to the corresponding parameter.
     *
     * @param form     The new form for the figure
     */
    public void setForm(Form form){
        this.form = form;
    }

    /**
     * Implements the clone() method of Object.
     * Returns a deep copy of the Figure object.
     *
     * @return      The deep copy of the figure
     */
    public Figure clone(){
        Figure copy = null;
        try {
            copy = (Figure) super.clone();
        }
        catch (CloneNotSupportedException e){
            System.out.println("Not cloneable");
        }
        return copy;
    }

    /**
     * Returns a String representation of the figure.
     *
     * @return      The String representation
     */
    public String toString(){
        return "" + color.toString().charAt(0) +
                height.toString().charAt(0) +
                shape.toString().charAt(0) +
                form.toString().charAt(0);
    }

    /**
     * Checks whether the two figures have the same color, height, shape and form.
     *
     * @param other     The other Figure to be compared with
     * @return          Boolean value whether the instance variables are the same
     */
    public boolean isSame(Figure other){
        return isSameColor(other) && isSameHeight(other) && isSameShape(other) && isSameForm(other);
    }

    /**
     * Checks if the Figure object has the same color as the Figure other.
     *
     * @param other     The object to be compared with
     * @return          Boolean value whether their colors are the same or not
     */
    public boolean isSameColor(Figure other){
        return  this.color == other.color;
    }

    /**
     * Checks if the Figure object has the same height as the Figure other.
     *
     * @param other     The object to be compared with
     * @return          Boolean value whether their heights are the same or not
     */
    public boolean isSameHeight(Figure other){
        return this.height == other.height;
    }

    /**
     * Checks if the Figure object has the same shape as the Figure other.
     *
     * @param other     The object to be compared with
     * @return          Boolean value whether their shapes are the same or not
     */
    public boolean isSameShape(Figure other){
        return this.shape == other.shape;
    }

    /**
     * Checks if the Figure object has the same form as the Figure other.
     *
     * @param other     The object to be compared with
     * @return          Boolean value whether their forms are the same or not
     */
    public boolean isSameForm(Figure other){
        return  this.form == other.form;
    }
}