package am.aua.quarto.core.figures;

/**
 * The ExtraFigure class encapsulates the behavior of extra figures included in the
 * game that are not part of the original game.
 * It is a subclass of the Figure class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public abstract class ExtraFigure extends Figure{

}
