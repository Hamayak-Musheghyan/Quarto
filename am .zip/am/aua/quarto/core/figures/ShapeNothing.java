package am.aua.quarto.core.figures;
/**
 * The ShapeNothing class encapsulates the behavior of the figures
 * called shape nothings that don't match with any figure by shape.
 * It is a subclass of ExtraFigure base class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class ShapeNothing extends ExtraFigure {
    /**
     * Constructs a new ShapeNothing object given the height,
     * color and form of it.
     *
     * @param height        The Height height of the figure
     * @param color         The Color color of the figure
     * @param form          The Form form of the figure
     */
    public ShapeNothing(Color color, Height height, Form form){
        this.height = height;
        this.shape = null;
        this.form = form;
        this.color = color;
    }


    /**
     * Returns false if compared with another figure
     * regarding the shape characteristic.
     *
     * @param other     Figure object
     * @return          false, as it doesn't match with any object by shape
     */
    public boolean isSameShape(Figure other){
        return  false;
    }
}
