package am.aua.quarto.core.figures;
/**
 * The SuperJoker class encapsulates the behavior of the figures
 * called super jokers that can match with any figure by any feature.
 * It is a subclass of ExtraFigure base class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class SuperJoker extends ExtraFigure {

    /**
     * Constructs a new SuperJoker object with features are null.
     *
     */
    public SuperJoker(){
        this.height = null;
        this.shape = null;
        this.form = null;
        this.color = null;
    }


    /**
     * Returns true if compared with another figure
     * regarding the color characteristic.
     *
     * @param other     Figure object
     * @return          true, as it matches with any object by color
     */
    public boolean isSameColor(Figure other){
        return  true;
    }
    /**
     * Returns true if compared with another figure
     * regarding the height characteristic.
     *
     * @param other     Figure object
     * @return          true, as it matches with any object by height
     */
    public boolean isSameHeight(Figure other){
        return true;
    }
    /**
     * Returns true if compared with another figure
     * regarding the shape characteristic.
     *
     * @param other     Figure object
     * @return          true, as it matches with any object by shape
     */
    public boolean isSameShape(Figure other){
        return true;
    }
    /**
     * Returns true if compared with another figure
     * regarding the form characteristic.
     *
     * @param other     Figure object
     * @return          true, as it matches with any object by form
     */
    public boolean isSameForm(Figure other){
        return  true;
    }
}
