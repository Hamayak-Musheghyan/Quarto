package am.aua.quarto.core.figures;
/**
 * The FormNothing class encapsulates the behavior of the figures
 * called form nothings that don't match with any figure by form.
 * It is a subclass of ExtraFigure base class.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class FormNothing extends ExtraFigure {
    /**
     * Constructs a new FormNothing object given the height,
     * shape and color of it.
     *
     * @param height        The Height height of the figure
     * @param shape         The Shape shape of the figure
     * @param color          The Color color of the figure
     */
    public FormNothing(Color color, Height height, Shape shape){
        this.height = height;
        this.shape = shape;
        this.form = null;
        this.color = color;
    }

    /**
     * Returns false if compared with another figure
     * regarding the form characteristic.
     *
     * @param other     Figure object
     * @return          false, as it doesn't match with any object by form
     */
    public boolean isSameForm(Figure other){
        return  false;
    }
}
