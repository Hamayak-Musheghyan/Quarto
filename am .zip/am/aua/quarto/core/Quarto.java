package am.aua.quarto.core;
/**
 * The <code>Quarto</code> class encapsulates the state of an ongoing game of
 * quarto and contains all the neccessary methods to perform any action related to the game.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
import am.aua.quarto.core.figures.*;
import java.util.Scanner;

public class Quarto {
    /**
     * The length of the Quarto board.
     */
    public static final int BOARD_LENGTH = 4;
    /**
     * The height of the Quarto board.
     */
    public static final int BOARD_HEIGHT = 4;
    /**
     * The empty cell of the Quarto board.
     */
    private static Figure EMPTY = null;

    private Puttable[][] board;
    private int counter;
    private Figure[] figures;
    private Player p1;
    private Player p2;


    /**
     * Constructs new Quarto object, such that the board contains no figures and all the cells
     * are empty. Also the static figures are created, which will be used by players to play
     * the game.
     */
    public Quarto (){

        this.counter = 0;
        this.board = new Figure[BOARD_LENGTH][BOARD_HEIGHT];

        // creation of the static figures
        Figure WTRS = new Figure(Figure.Color.WHITE, Figure.Height.TALL, Figure.Shape.ROUND, Figure.Form.SOLID);
        Figure WTRH = new Figure(Figure.Color.WHITE, Figure.Height.TALL, Figure.Shape.ROUND, Figure.Form.HOLLOW);
        Figure WTSS = new Figure(Figure.Color.WHITE, Figure.Height.TALL, Figure.Shape.SQUARE, Figure.Form.SOLID);
        Figure WTSH = new Figure(Figure.Color.WHITE, Figure.Height.TALL, Figure.Shape.SQUARE, Figure.Form.HOLLOW);

        Figure WSRS = new Figure(Figure.Color.WHITE, Figure.Height.SHORT, Figure.Shape.ROUND, Figure.Form.SOLID);
        Figure WSRH = new Figure(Figure.Color.WHITE, Figure.Height.SHORT, Figure.Shape.ROUND, Figure.Form.HOLLOW);
        Figure WSSS = new Figure(Figure.Color.WHITE, Figure.Height.SHORT, Figure.Shape.SQUARE, Figure.Form.SOLID);
        Figure WSSH = new Figure(Figure.Color.WHITE, Figure.Height.SHORT, Figure.Shape.SQUARE, Figure.Form.HOLLOW);

        Figure BTRS = new Figure(Figure.Color.BLACK, Figure.Height.TALL, Figure.Shape.ROUND, Figure.Form.SOLID);
        Figure BTRH = new Figure(Figure.Color.BLACK, Figure.Height.TALL, Figure.Shape.ROUND, Figure.Form.HOLLOW);
        Figure BTSS = new Figure(Figure.Color.BLACK, Figure.Height.TALL, Figure.Shape.SQUARE, Figure.Form.SOLID);
        Figure BTSH = new Figure(Figure.Color.BLACK, Figure.Height.TALL, Figure.Shape.SQUARE, Figure.Form.HOLLOW);

        Figure BSRS = new Figure(Figure.Color.BLACK, Figure.Height.SHORT, Figure.Shape.ROUND, Figure.Form.SOLID);
        Figure BSRH = new Figure(Figure.Color.BLACK, Figure.Height.SHORT, Figure.Shape.ROUND, Figure.Form.HOLLOW);
        Figure BSSS = new Figure(Figure.Color.BLACK, Figure.Height.SHORT, Figure.Shape.SQUARE, Figure.Form.SOLID);
        Figure BSSH = new Figure(Figure.Color.BLACK, Figure.Height.SHORT, Figure.Shape.SQUARE, Figure.Form.HOLLOW);

        this.figures = new Figure[]{WTRS, WTRH, WTSS, WTSH, WSRS, WSRH, WSSS, WSSH, BTRS, BTRH, BTSS, BTSH, BSRS, BSRH, BSSS, BSSH};

        for (int i = 0; i < BOARD_LENGTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                if (i == 3 && j == 1)
                    continue;
                this.board[i][j] = EMPTY;
            }
        }

    }

    /**
     * Returns a deep copy of the Puttable[][] board but only
     * includes the Figure objects, and not the
     * @return
     */
    public Figure[][] getBoard(){
        Figure[][] board = new Figure[BOARD_LENGTH][BOARD_HEIGHT];
        for (int i = 0; i < BOARD_LENGTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                Figure current = (Figure) this.board[i][j];
                if(board[i][j] != null)
                    board[i][j] = current.clone();
            }
        }
        return board;
    }


    /**
     * Returns the number 0 or 1 to determine who's turn it is
     * from the two players.
     *
     * @return      0 or 1 to determine the turn of the player.
     */
    public int getTurn(){
        return counter%2;
    }

    /**
     * Returns the value of the counter.
     *
     * @return      int counter
     */
    public int getCounter(){
        return this.counter;
    }

    /**
     * Returns a deep copy of the Figure[] array containing the static figures.
     *
     * @return      Figure[] deep copy of the figures array.
     */
    public Figure[] getFigures(){
        Figure[] copy = new Figure[figures.length];
        for (int i = 0; i < copy.length; i++) {
            if (figures[i] != null) {
                copy[i] = figures[i].clone();
            }

        }
        return copy;
    }

    /**
     * Returns the player 1
     *
     * @return      Player p1
     */
    public Player getP1(){
        return p1;
    }

    /**
     * Returns the player 2
     *
     * @return      Player p2
     */
    public Player getP2(){
        return p2;
    }

    /**
     * Sets the name of the human player with the parameter String name.
     *
     * @param name      The String name for the human player.
     */
    public void setP1(String name){
        p1 = new HumanPlayer(name);
    }

    /**
     * Sets the name of the computer player as Computer, if it is given as argument,
     * or assigns that name to the human player.
     *
     * @param name      String name for either the computer player or the human player.
     */
    public void setP2(String name){
       if(name != "Computer"){
           p2 = new HumanPlayer(name);
       }
       else {
           p2 = new ComputerPlayer();
       }
    }

    /**
     * Returns the boolean value whether the game is over.
     *
     * @return      Whether the game is over.
     */
    public boolean isGameOver(){
        return false;
    }

    /**
     * Chechs if at the given Position p the board doesn't contain a figure.
     *
     * @param p     The Position to check
     * @return      The boolean value whether it si empty at p or not
     */
    public boolean isEmpty(Position p){
        return this.board[p.getRow()][p.getColumn()] == null;
    }

    /**
     * Returns the Figure figure at Position p.
     *
     * @param p     The Position used to return the figure
     * @return      The Figure object at p
     */
    private Figure getPieceAt(Position p){
        return (Figure) this.board[p.getRow()][p.getColumn()];
    }

    public Figure takeFigure(int index){
        Figure f = null;
        if(figures[index] != null) {
            f = this.figures[index];
        }
        this.figures[index] = null;
        return f;
    }

    /**
     * Performs the put action on the board by adding at the given Position p
     * the given Figure f if the arguments are valid. If they are valid, the method
     * also returns true, otherwise, false.
     *
     * @param p     Position where the figure is put
     * @param f     Figure object that is put at Position p
     * @return      Boolean value whether the put action was performed or not
     */
     public boolean performPut (Position p, Figure f){
        if(this.getPieceAt(p) == null && f != null){
            this.board[p.getRow()][p.getColumn()] = f;
            counter++;
            return true;
        }
        return false;
    }


}
