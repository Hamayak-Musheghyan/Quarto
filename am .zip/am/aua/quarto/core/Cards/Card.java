package am.aua.quarto.core.Cards;
import am.aua.quarto.core.figures.Puttable;
/**
 * The Card class encapsulates the behavior of the cards used for the game.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class Card implements Puttable{
    /**
     * The message of the card
     */
    private String message;
    /**
     * The point of the card
     */
    private int point;


    /**
     * Constructs a new Card with the given message.
     *
     * @param message       The message of the card
     * @param point         The points of the card
     */
    public Card(String message, int point){
        this.point = point;
        this.message = message;
    }

}
