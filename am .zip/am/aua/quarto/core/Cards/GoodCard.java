package am.aua.quarto.core.Cards;
/**
 * The GoodCard class encapsulates the behavior of the good cards.
 * It is a subclass of the base class Card.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class GoodCard extends Card{
    /**
     * Constructs a new Card with the corresponding message.
     */
    public GoodCard(){
        super("You picked a good card. ", 100);
    }
}
