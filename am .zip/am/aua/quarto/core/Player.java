package am.aua.quarto.core;

/**
 * The Player class encapsulates the behavior of the players of the
 * Quarto game.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */

public class Player {
    /**
     * The String name for the player
     */
    private String name;

    /**
     * Constructs a player with the name "Anonymous player".
     */
    public Player(){
        this("Anonymous Player");
    }

    /**
     * Constructs a player using the given String name.
     *
     * @param name      The String name for the player
     */
    public Player(String name){
        this.name = name;
    }

    /**
     * Returns the String name of the Player.
     *
     * @return      The String name
     */
    public String getName(){
        return this.name;
    }

    /**
     * Sets the value of name as the given parameter String name.
     *
     * @param name      The String name for the player
     */
    public void setName(String name){
        this.name = name;
    }
}
