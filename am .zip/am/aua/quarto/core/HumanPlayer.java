package am.aua.quarto.core;

/**
 * The HumanPlayer class encapsulates the behavior of the Human player.
 * It is a subclass of the base class Player.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class HumanPlayer extends Player{
    /**
     * The points of the human player.
     */
    private int points;

    /**
     * Constructs a human player using the given String name for it.
     *
     * @param name      The String name for the player
     */
    public HumanPlayer(String name){
        super(name);
    }
}
