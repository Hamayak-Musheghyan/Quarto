package am.aua.quarto.core;

/**
 * The ComputerPlayer class encapsulates the behavior of the computer player.
 * It is a subclass of the base class Player.
 *
 * @author Ina Grigoryan <a href="mailto:ina_grigoryan@edu.aua.am">ina_grigoryan@edu.aua.am</a>
 * @author Davit Vanyan <a href="mailto:davit_vanyan@edu.aua.am">davit_vanyan@edu.aua.am</a>
 * @author Hamayak Musheghyan <a href="mailto:hamayak_musheghyan@edu.aua.am">hamayak_musheghyan@edu.aua.am</a>
 * @version 1.0
 * @since 1.0
 */
public class ComputerPlayer extends Player{

    /**
     * The difficulty level of the Computer player.
     */
    private Difficulty difficulty;

    public enum Difficulty {EASY, MEDIUM, HARD}

    /**
     * Constructs a new ComputerPlayer object with the name Computer
     * and the easy difficulty.
     */
    public ComputerPlayer(){
        this("EASY");
    }

    /**
     * Constructs a new ComputerPlayer object with the given difficulty
     * as parameter and the name Computer.
     * @param difficulty        The difficulty of the ComputerPlayer
     */
    public ComputerPlayer(String difficulty){
        super("Computer");
        this.difficulty = Difficulty.valueOf(difficulty);
    }
}
